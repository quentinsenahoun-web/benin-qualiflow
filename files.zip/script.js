document.addEventListener("DOMContentLoaded", () => {

    // ── NAVBAR SCROLL ──
    const navbar = document.getElementById("navbar");
    if (navbar) {
        window.addEventListener("scroll", () => {
            navbar.classList.toggle("scrolled", window.scrollY > 40);
        });
    }

    // ── BURGER MENU ──
    const burger = document.getElementById("burger");
    const nav = document.querySelector("nav");
    if (burger && nav) {
        burger.addEventListener("click", () => {
            nav.classList.toggle("open");
        });
    }

    // ── LANGUAGE SWITCHER ──
    const switcher = document.getElementById("languageSwitcher");
    if (switcher) {
        switcher.addEventListener("change", () => {
            const lang = switcher.value;
            document.querySelectorAll("[data-fr]").forEach(el => {
                const text = el.getAttribute(`data-${lang}`);
                if (text) el.innerHTML = text;
            });
        });
    }

    // ── SCROLL REVEAL ──
    const reveals = document.querySelectorAll(".reveal");
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(e => {
            if (e.isIntersecting) {
                e.target.classList.add("active");
                observer.unobserve(e.target);
            }
        });
    }, { threshold: 0.12 });
    reveals.forEach(el => observer.observe(el));

    // ── COUNTERS ──
    const counters = document.querySelectorAll(".counter");
    const counterObs = new IntersectionObserver((entries) => {
        entries.forEach(e => {
            if (e.isIntersecting) {
                animateCounter(e.target);
                counterObs.unobserve(e.target);
            }
        });
    }, { threshold: 0.5 });
    counters.forEach(c => counterObs.observe(c));

    function animateCounter(el) {
        const target = parseInt(el.dataset.target);
        const duration = 1800;
        const start = performance.now();
        const update = (now) => {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = Math.floor(eased * target).toLocaleString('fr-FR');
            if (progress < 1) requestAnimationFrame(update);
            else el.textContent = target.toLocaleString('fr-FR') + (target >= 100 ? '+' : '');
        };
        requestAnimationFrame(update);
    }
});

// ── CONTACT FORM ──
function handleContact(e) {
    e.preventDefault();
    const btn = e.target.querySelector("button");
    btn.innerHTML = '<i class="fa-solid fa-check"></i> Message envoyé !';
    btn.style.background = 'var(--green)';
    btn.disabled = true;
    setTimeout(() => {
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Envoyer le message';
        btn.style.background = '';
        btn.disabled = false;
        e.target.reset();
    }, 3000);
}
